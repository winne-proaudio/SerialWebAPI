namespace SerialWebAPI.Models;

public class CommandRequest
{
    public string Command { get; set; } = string.Empty;
}